import java.util.ArrayList;

public class BankAccount {

	@SuppressWarnings("unused")
	private static final String TranscationList = null;
	String state;
    int accountNumber;
    public double balance;
    public ArrayList<Double> TransactionList = null;
	@SuppressWarnings("unused")
	private String identity;
	@SuppressWarnings("rawtypes")
	private ArrayList Transection;
	private int TransectionTimes;
    
    public BankAccount(){
        this(-1,-1);
    }
    
    BankAccount(int _accountNumber){this.accountNumber=_accountNumber;this.balance=0;}

    BankAccount(int _accountNumber,double Balance)
        {
    	this.identity="open";
    	this.accountNumber=_accountNumber;this.balance=Balance;
    	this.Transection=new ArrayList<>();
    	}

    public int getAccountNumber()
    {
    	return this.accountNumber;
    }

    public double getBalance()
    {
    	return this.balance;
    }

    int retrieveNumberOfTransactions(){return this.TransectionTimes;}
    	
    void deposit(double amount)
        {
    	if(isOpen()&&amount>=0)
    	 {
    		this.balance=balance+amount;
    		addTransection(amount);
    		this.TransectionTimes+=1;
    	 }
    	else{System.out.println("�s�ڿ��~ "+amount);}
    	}

    private boolean isOpen() {
		// TODO Auto-generated method stub
		return false;
	}

	void withdraw(double amount)
        {
    	if(isOpen()&&amount>=0&&amount<=this.balance)
    	 {
    		this.balance=this.balance-amount;
    	    addTransection(0-amount);
    	    this.TransectionTimes+=1;
    	 }
    	else{System.out.println("���ڿ��~ "+amount);}
    	}

    @SuppressWarnings("unchecked")
	void addTransection(double amount){this.Transection.add(amount);}

    String getTransections()
        {
    	String result="";
    	for(int i=0;i<this.Transection.size();i++)
    	{
    		result=result+(i+1)+":"+this.Transection.get(i)+"\n";
    	}
    	return result;
    	}
    void suspend()
    {
    	if(!isClosed()&&isOpen())
    	{this.identity="suspend";}
    }
    

	private boolean isClosed() {
		// TODO Auto-generated method stub
		return false;
	}

	void close() {
	}
	
	


	
	
}
