import java.util.HashMap;

public class Bank {
	HashMap<Integer, BankAccount> BankList = new HashMap<Integer, BankAccount>();
	void addAccount(int accountNumber,double initialBalance){
		if(initialBalance<0)
			initialBalance=0;
		BankList.put(accountNumber, new BankAccount());
		}
	void deposit(int accountNumber,double initialBalance){
		BankAccount value=(BankAccount) BankList.get(accountNumber); 
		try{
			value.deposit(initialBalance);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	void withdraw(int accountNumber,double initialBalance)
	{
		BankAccount value=(BankAccount) BankList.get(accountNumber);
		try{
			value.withdraw(initialBalance);
			}
		catch(Exception e){
			System.out.println(e.getMessage());
			}
	}
		double getBalance(int accountNumber){
			BankAccount value=(BankAccount) BankList.get(accountNumber);
			return value.getBalance();
	}
		void reOpenAccount (int accountNumber){
			 BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
			 tempAccount.reOpen();
		}
	  
		void suspendAccount(int accountNumber){
			BankAccount value=(BankAccount) BankList.get(accountNumber);
			value.suspend();	
		}
		
		void closeAccount (int accountNumber){
			 BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
			 tempAccount.close();
			}
		String getAccountStatus(int accountNumber){
			BankAccount value=(BankAccount) BankList.get(accountNumber);
		   return BankAccount.state;
		}
		
		String summarizeAccountTransactions(int accountNumber){
			
			StringBuffer stringbuffer = new StringBuffer();
			BankAccount tempAccount = (BankAccount)BankList.get(accountNumber);
			
			stringbuffer.append("Account #" + accountNumber + "transaction:\n\n");
			stringbuffer.append(tempAccount.getTransactions());
			stringbuffer.append("End of transactions\n");
			
			return stringbuffer.toString();
		}
		
		 String summarizeAllAccounts (){
		        StringBuffer stringbuffer = new StringBuffer();
		        stringbuffer.append("Account\tBalance\t#Transcations\tStatus\n");
		        for (BankAccount bank :BankList.values()){
		            stringbuffer.append(bank.accountNumber + "\t");
		            stringbuffer.append(bank.getBalance() + "\t");
		            stringbuffer.append(bank.retrieveNumberOfTransactions() + "\t\t");
		            stringbuffer.append(BankAccount.state + "\n");
		        }
		        stringbuffer.append("End of Account Summary" + "\n");
		        return stringbuffer.toString();
		    }
		
		
		
		
	}
