import java.util.ArrayList;

public class BankAccount {

    int accountNumber;
	public int TransectionTimes;
	public double getBalance;
	String status = "open";
	ArrayList<Double> TranscationList = new ArrayList<Double>();
	
	public BankAccount(int i, double initialBalance) {
		this.accountNumber=i;this.getBalance=initialBalance;
		this.TranscationList=new ArrayList<>();
		
	}
	public void deposit(double initialBalance) {
		if(isOpen()&&accountNumber>=0)
		 {
			this.getBalance=getBalance+accountNumber;
			this.TransectionTimes+=1;
			addTransection(accountNumber);
			
		 }
		else{System.out.println("Deposit Error "+accountNumber);}
	}

	private void addTransection(int i) {
		// TODO Auto-generated method stub
		
	}
	public void withdraw(double initialBalance) {
		if(isOpen()&&accountNumber>=0&&accountNumber<=this.getBalance)
		 {
			this.getBalance=this.getBalance-accountNumber;
		    addTransection(0-accountNumber);
		    this.TransectionTimes+=1;
		 }
		else{System.out.println("Withdraw Error "+accountNumber);}
		
	}

	public void suspend() {
		this.status="suspend";
		
	}

	public void reOpen() {
	this.status="open";
		
	}

	public void close() {
		status = "close";
		}

	public String getStatus() {
		
		return status;
	}

	public int getTrancactions() {
		
		return TranscationList.size();
	}

	public String getAccountNumber() {
		
		return null;
	}
	boolean isOpen() {
		if(this.status.equals("open"))
			return true;
		else{
			return false;
		}
	}
	
	boolean isSuspended(){
		if(this.status.equals("suspend"))
			return true;
		else{
			return false;
		}
	}
	public boolean isClosed() {
		return status.equals("close");
	}

	public void addTranscation(double amount) {
		TranscationList.add(amount);
	}
	public String getBalance() {
		// TODO Auto-generated method stub
		return null;
	}
	public int retrieveNumberOfTransactions() {
		return TranscationList.size();
	}

	
}
