import java.util.ArrayList;
public class bank {
  
	ArrayList<BankAccount> Account = new ArrayList<>();
	
	public bank() {
                }
	public BankAccount findAccount(int accountNumber) {
		BankAccount myAccount = null;
		for (BankAccount acc : Account) {
			if (acc.accountNumber == accountNumber)
				myAccount = acc;
		}
		return myAccount;
}
	void addAccount(int i,double initialBalance){
		BankAccount acc=new BankAccount(i,initialBalance);
		Account.add(acc);		
	}
	
	void deposit(int accountNumber, double initialBalance) {
		findAccount(accountNumber).deposit(initialBalance);
	}
    
	void withdraw(int accountNumber, double initialBalance) {
		findAccount(accountNumber).withdraw(initialBalance);
	}
    
	double getBalance(int accountNumber) {
		return findAccount(accountNumber).getBalance;
	}

	void suspendAccount(int accountNumber){
		findAccount(accountNumber).suspend();
	}
	
	void reOpenAccount(int accountNumber){
		findAccount(accountNumber).reOpen();
	}

	void closeAccount(int accountNumber){
		findAccount(accountNumber).close();
	}
	
	String getAccountStatus(int accountNumber){
		return findAccount(accountNumber).getStatus();
	}
	
	int summarizeAccountTransactions(int accountNumber){
		return findAccount(accountNumber).getTrancactions();
	}
    
	String summarizeAllAccounts(){
		String summary = "Bank Account Summary   \n\nAccount        Balance      #Transactions       Status \n";
		for (int i=0;i<Account.size();i++){
			
			
			summary+=Account.get(i).getAccountNumber()+" "+Account.get(i).getBalance()+" "+
					( Account.get(i)).retrieveNumberOfTransactions()+" "+Account.get(i).status+"\n";
	}
		summary+="End of Account Summary";
		return summary;
	}
}
